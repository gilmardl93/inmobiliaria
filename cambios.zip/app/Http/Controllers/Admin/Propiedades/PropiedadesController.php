<?php

namespace App\Http\Controllers\Admin\Propiedades;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Propiedad;

class PropiedadesController extends Controller
{
    public function buscar(Request $request)
    {
    	
    }
}

		{!! Html::script('admin/assets/global/plugins/moment.min.js') !!}
        {!! Html::script('admin/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js') !!}
        {!! Html::script('admin/assets/global/plugins/morris/morris.min.js') !!}
        {!! Html::script('admin/assets/global/plugins/morris/raphael-min.js') !!}
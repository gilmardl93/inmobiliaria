
        <div class="footer-area">


            <div class="footer-copy text-center">
                <div class="container">
                    <div class="row">
                        <div class="pull-left">
                            <span> (C) <a href="">Gilmar Moreno</a> , Todos los derechos reservados  </span> 
                        </div> 
                    </div>
                </div>
            </div>

        </div>